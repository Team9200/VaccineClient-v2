const fs = require("fs")
var file = './d3.txt';
var data = fs.readFileSync(file);

let receiveBuffer = []
var receiveString = new String();

function base64Encode(data) {
	return new Buffer.from(data).toString('base64');
};

function sliceEncodedData(encoded_data, offset) {
	return encoded_data.substring(offset, offset+chunkSize);
};

var encoded_data = base64Encode(data);

const chunkSize = 20;

console.log("full encoded data : ", encoded_data);

for(var i=0, j=0; i<encoded_data.length; i+=chunkSize, j++) {
	sliced_data = sliceEncodedData(encoded_data, i);
	var Malware = new Object();
	Malware.filename = 'd3.txt';
	Malware.num = j;
	Malware.size = data.size;
	Malware.binary = sliced_data;

	console.log(JSON.stringify(Malware));
	receiveBuffer.push(JSON.stringify(Malware));
}

console.log("received Buffer : ", receiveBuffer);

receiveBuffer.forEach((value) => {
		receiveString = receiveString.concat(JSON.parse(value).binary);
	}
);

console.log(Buffer.from(receiveString, 'base64').toString('ascii'));
